package com.example.orderservice.dto;
import com.example.orderservice.entity.OrderStatus;
public class UpdateOrderStatusRequest {
	private OrderStatus status;

    public OrderStatus getStatus() {
        return status;
    }

    public void setStatus(OrderStatus status) {
        this.status = status;
    }
}
