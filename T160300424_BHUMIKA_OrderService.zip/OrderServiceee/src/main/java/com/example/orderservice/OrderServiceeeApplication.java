package com.example.orderservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderServiceeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderServiceeeApplication.class, args);
	}

}
